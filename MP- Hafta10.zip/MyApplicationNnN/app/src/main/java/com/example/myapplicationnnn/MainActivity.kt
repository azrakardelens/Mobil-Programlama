package com.example.haritaservisi

import android.R
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplicationnnn.CurrentLocationActivity
import com.example.myapplicationnnn.SetLocationActivity

class MainActivity : AppCompatActivity() {
    var btnCurrent: Button? = null
    var btnSet: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnCurrent = findViewById<Button>(R.id.btnCurrent)
        btnSet = findViewById<Button>(R.id.btnSet)

        btnCurrent.setOnClickListener(View.OnClickListener { v: View? ->
            startActivity(
                Intent(
                    this,
                    CurrentLocationActivity::class.java
                )
            )
        })

        btnSet.setOnClickListener(View.OnClickListener { v: View? ->
            startActivity(
                Intent(
                    this,
                    SetLocationActivity::class.java
                )
            )
        })
    }
}