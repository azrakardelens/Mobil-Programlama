package com.example.myapplicationnnn

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*

class CurrentLocationActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_current_location)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment

        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        val konum = LatLng(41.0082, 28.9784)

        mMap.addMarker(
            MarkerOptions()
                .position(konum)
                .title("Mevcut Konum")
        )

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(konum, 12f))
    }
}